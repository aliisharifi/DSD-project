from openpyxl import Workbook
from openpyxl.styles import Alignment


workbook = Workbook()

# implementation no. 1 #################################################################################################


def get_name(matrix, row, column):
    return matrix + str(row) + str(column)


def write_registers_in_sheet(sheet, start, n, pej,  a, bu, bm, bl, c):
    def write_row(row_num, arr):
        for i in range(1, n + 2):
            sheet.cell(start + row_num, i).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            sheet.cell(start + row_num, i).value = arr[i - 1]

    write_row(0, pej)
    write_row(1, a)
    write_row(2, bu)
    write_row(3, bm)
    write_row(4, bl)
    for i in range(n):
        write_row(5 + i, c[i])
    # write_row(5 + n, (n + 1) * ['#'])


sheet = workbook.active
sheet.title = 'implementation_no1'

n = 6
PEj = ['PEj'] + ['PE' + str(i) for i in range(1, n + 1)]
A = ['A'] + n * ['.']
BU = ['BU'] + n * ['.']
BM = ['BM'] + n * ['.']
BL = ['BL'] + n * ['.']
C = [['C' + str(i) + 'j'] + n * [''] for i in range(1, n + 1)]

each_chart_height = 5 + n + 1
start = 1

a_row, a_column = 1, 1
b_row, b_column = 1, 1

for i in range(n):
    BU[2:] = BU[1:n]
    BU[1] = get_name('b', b_row, b_column)

    for j in range(1, n + 1):
        if BU[j][-1] == str(j):
            BL[j] = BM[j]
            BM[j] = BU[j]

    write_registers_in_sheet(sheet, start, n, PEj, A, BU, BM, BL, C)
    start += each_chart_height
    b_column += 1

b_row, b_column = 2, 1

for i in range(n * n + n):
    A[2:] = A[1:n]
    A[1] = get_name('a', a_row, a_column) if i < n * n else '.'
    BU[2:] = BU[1:n]
    BU[1] = get_name('b', b_row, b_column) if i < n * n - n else '.'

    for j in range(1, n + 1):
        if BU[j][-1] == str(j):
            BL[j] = BM[j]
            BM[j] = BU[j]
        if len(BM[j]) > 1 and A[j][-1] == BM[j][1]:
            C[int(A[j][1]) - 1][j] += ('\n' + A[j] + '*' + BM[j])
        if len(BL[j]) > 1 and A[j][-1] == BL[j][1]:
            C[int(A[j][1]) - 1][j] += ('\n' + A[j] + '*' + BL[j])

    write_registers_in_sheet(sheet, start, n, PEj, A, BU, BM, BL, C)
    start += each_chart_height
    if a_row % n == 0:
        a_row, a_column = 0, a_column + 1
        b_row, b_column = b_row + 1, 0
    b_column += 1
    a_row += 1

workbook.save('implementations.xlsx')

########################################################################################################################

workbook.close()

if __name__ == "__main__":
    pass
