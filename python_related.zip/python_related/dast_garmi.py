def func(a):
    a += 5


a = 3
func(a)
print(a)